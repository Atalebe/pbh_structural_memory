import numpy as np

# =========================
# Configuration parameters
# =========================

SEED          = 56789          # RNG seed for reproducibility
N_LIST        = [100, 300, 500, 1000, 3000, 5000]   # catalog sizes to test
N_REALISATIONS = 500           # number of simulations per N per true model

# "True" log-normal component (in natural log of mass)
MU_LN_TRUE    = np.log(10.0)   # log of 10 Msun
SIGMA_LN_TRUE = 0.5            # width in ln M

# Power-law tail parameters: p(M) ∝ M^BETA on [M_MIN_TAIL, M_MAX_TAIL]
BETA_TRUE     = -2.0
M_MIN_TAIL    = 20.0           # Msun
M_MAX_TAIL    = 100.0          # Msun

# Mixture fraction for the tail in the dual model
F_TAIL_TRUE   = 0.25           # 25% of PBHs in the tail

# Approximate measurement noise in ln M (optional)
SIGMA_MEAS_LN = 0.10           # 0.1 dex-ish in ln-space (small)

# Bayes-factor threshold for "strong evidence"
LN_B_THRESHOLD = 5.0

# =========================
# RNG
# =========================

rng = np.random.default_rng(SEED)

# =========================
# PDF and sampling helpers
# =========================

def sample_lognormal_masses(N, mu_ln, sigma_ln, rng):
    """Sample N masses from a log-normal distribution in ln M."""
    lnM = rng.normal(loc=mu_ln, scale=sigma_ln, size=N)
    M   = np.exp(lnM)
    return M

def lognormal_pdf(M, mu_ln, sigma_ln):
    """Log-normal PDF in M (natural log)."""
    M = np.asarray(M)
    lnM = np.log(M)
    norm = 1.0 / (M * sigma_ln * np.sqrt(2.0 * np.pi))
    return norm * np.exp(-0.5 * ((lnM - mu_ln) / sigma_ln)**2)

def sample_powerlaw_masses(N, beta, m_min, m_max, rng):
    """
    Sample N masses from a power-law p(M) ∝ M^beta on [m_min, m_max].
    Assumes beta != -1.
    """
    beta = float(beta)
    m_min = float(m_min)
    m_max = float(m_max)
    u = rng.random(N)
    # Inverse CDF for power-law:
    # F(M) = (M^(beta+1) - m_min^(beta+1)) / (m_max^(beta+1) - m_min^(beta+1))
    a = beta + 1.0
    denom = m_max**a - m_min**a
    M = (m_min**a + u * denom)**(1.0 / a)
    return M

def powerlaw_pdf(M, beta, m_min, m_max):
    """Normalized power-law PDF p(M) ∝ M^beta on [m_min, m_max]."""
    M = np.asarray(M)
    beta = float(beta)
    m_min = float(m_min)
    m_max = float(m_max)

    # Normalization
    a = beta + 1.0
    norm = a / (m_max**a - m_min**a)

    pdf = norm * (M**beta)
    # Zero outside [m_min, m_max]
    pdf[(M < m_min) | (M > m_max)] = 0.0
    return pdf

def sample_dual_component_masses(N, rng):
    """
    Sample N masses from the dual model:
      with prob (1 - F_TAIL_TRUE) from log-normal,
      with prob F_TAIL_TRUE from power-law tail.
    """
    # Decide how many from tail
    n_tail = rng.binomial(N, F_TAIL_TRUE)
    n_ln   = N - n_tail

    M_ln   = sample_lognormal_masses(n_ln, MU_LN_TRUE, SIGMA_LN_TRUE, rng)
    M_tail = sample_powerlaw_masses(n_tail, BETA_TRUE, M_MIN_TAIL, M_MAX_TAIL, rng)

    M = np.concatenate([M_ln, M_tail])
    rng.shuffle(M)
    return M

def apply_measurement_noise_ln(M, sigma_meas_ln, rng):
    """Apply Gaussian noise in ln M to mimic measurement uncertainty."""
    lnM_true = np.log(M)
    lnM_obs  = lnM_true + rng.normal(loc=0.0, scale=sigma_meas_ln, size=len(M))
    return np.exp(lnM_obs)

# =========================
# Log-likelihoods and ln B
# =========================

def log_likelihood_single(M_obs):
    """
    Log-likelihood under single-component log-normal model.

    We estimate (mu_ln, sigma_ln) by the sample mean and std of ln M_obs
    (approximate MLE for log-normal).
    """
    lnM = np.log(M_obs)
    mu_hat = lnM.mean()
    sigma_hat = lnM.std(ddof=1) if len(lnM) > 1 else SIGMA_LN_TRUE

    pdf_vals = lognormal_pdf(M_obs, mu_hat, sigma_hat)
    pdf_vals = np.clip(pdf_vals, 1e-300, None)  # avoid log(0)
    lnL = np.sum(np.log(pdf_vals))
    return lnL, mu_hat, sigma_hat

def log_likelihood_dual(M_obs):
    """
    Log-likelihood under dual-component model with FIXED parameters equal
    to the "true" ones used for sampling.

      p(M) = (1 - F_TAIL_TRUE) * p_lognormal(M) + F_TAIL_TRUE * p_tail(M).

    This is optimistic (we're not fitting dual-model parameters), which is fine
    for a forecast of detectability.
    """
    pdf_ln   = lognormal_pdf(M_obs, MU_LN_TRUE, SIGMA_LN_TRUE)
    pdf_tail = powerlaw_pdf(M_obs, BETA_TRUE, M_MIN_TAIL, M_MAX_TAIL)

    pdf_mix = (1.0 - F_TAIL_TRUE) * pdf_ln + F_TAIL_TRUE * pdf_tail
    pdf_mix = np.clip(pdf_mix, 1e-300, None)
    lnL = np.sum(np.log(pdf_mix))
    return lnL

def lnB_simple(M_obs):
    """
    Approximate log Bayes factor ln B ≈ ln L_dual - ln L_single.
    """
    lnL_single, mu_hat, sigma_hat = log_likelihood_single(M_obs)
    lnL_dual = log_likelihood_dual(M_obs)
    return lnL_dual - lnL_single

# =========================
# Monte Carlo experiment
# =========================

def run_for_true_model(true_model, N, n_real, rng):
    """
    Run n_real simulations for a given true model and catalogue size N.
    true_model: "single" or "dual"
    Returns:
      lnB_vals: array of ln B values
    """
    lnB_vals = []

    for _ in range(n_real):
        if true_model == "single":
            # Draw from a pure log-normal with same "true" params
            M_true = sample_lognormal_masses(N, MU_LN_TRUE, SIGMA_LN_TRUE, rng)
        elif true_model == "dual":
            # Draw from dual-component model
            M_true = sample_dual_component_masses(N, rng)
        else:
            raise ValueError("true_model must be 'single' or 'dual'.")

        # Apply measurement noise in ln M
        M_obs = apply_measurement_noise_ln(M_true, SIGMA_MEAS_LN, rng)

        lnB = lnB_simple(M_obs)
        lnB_vals.append(lnB)

    return np.array(lnB_vals)

def main():
    print(f"SEED = {SEED}")
    print(f"N_LIST = {N_LIST}")
    print(f"N_REALISATIONS = {N_REALISATIONS}")
    print(f"LN_B_THRESHOLD = {LN_B_THRESHOLD}")
    print("\nRunning mass-function forecast...\n")

    # Storage for summary
    results_dual = []
    results_single = []

    for N in N_LIST:
        print(f"=== N = {N} ===")
        local_rng = np.random.default_rng(SEED + N)

        # 1) True model = dual-component
        lnB_dual = run_for_true_model("dual", N, N_REALISATIONS, local_rng)
        frac_detect = np.mean(lnB_dual > LN_B_THRESHOLD)

        # 2) True model = single-component
        lnB_single = run_for_true_model("single", N, N_REALISATIONS, local_rng)
        frac_false = np.mean(lnB_single > LN_B_THRESHOLD)

        results_dual.append(frac_detect)
        results_single.append(frac_false)

        print(f"  True dual:   mean lnB = {lnB_dual.mean():.2f}, "
              f"σ = {lnB_dual.std():.2f}, "
              f"P(lnB>5) = {frac_detect:.3f}")
        print(f"  True single: mean lnB = {lnB_single.mean():.2f}, "
              f"σ = {lnB_single.std():.2f}, "
              f"false alarm P(lnB>5) = {frac_false:.3f}")
        print()

    print("Summary:")
    for N, p_det, p_false in zip(N_LIST, results_dual, results_single):
        print(f"  N = {N:5d}:  P_detect (dual) ≈ {p_det:.3f},  "
              f"P_false ≈ {p_false:.3f}")


if __name__ == "__main__":
    main()
