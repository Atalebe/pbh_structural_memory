import numpy as np

# =========================
# Configuration parameters
# =========================

SEED            = 24680              # RNG seed for reproducibility

# Catalogue sizes to test (number of mergers)
N_LIST          = [100, 300, 500, 1000, 2000, 5000]

N_REALISATIONS  = 500                # simulations per (N, model)

# True dipole modulation amplitude (fractional)
ANISO_STRENGTH  = 0.03              # 3% modulation along CMB axis

# Angular localisation error (1-sigma) in radians (~10 deg)
SIGMA_LOC_DEG   = 10.0
SIGMA_LOC       = SIGMA_LOC_DEG * np.pi / 180.0

# Detection threshold in units of sigma (e.g. 3σ)
SIGMA_THRESHOLD = 3.0

# =========================
# RNG
# =========================

rng = np.random.default_rng(SEED)

# =========================
# Basic sphere utilities
# =========================

def random_isotropic_directions(n, rng):
    """Sample n isotropic unit vectors on the sphere."""
    u = rng.random(n)
    v = rng.random(n)
    theta = np.arccos(2*u - 1)
    phi = 2 * np.pi * v
    x = np.sin(theta) * np.cos(phi)
    y = np.sin(theta) * np.sin(phi)
    z = np.cos(theta)
    return np.vstack([x, y, z]).T  # shape (n, 3)


def random_gaussian_direction_around(n, n0, sigma_rad, rng):
    """
    Sample n unit vectors in a Gaussian angular patch around direction n0
    with angular standard deviation sigma_rad.

    Approximate small-angle construction: random offsets in the local
    tangent plane followed by renormalization.
    """
    n0 = np.asarray(n0, dtype=float)
    n0 /= np.linalg.norm(n0)

    # Construct orthonormal basis (e1, e2, n0)
    if np.allclose(n0, [0.0, 0.0, 1.0]):
        e1 = np.array([1.0, 0.0, 0.0])
    else:
        tmp = np.array([0.0, 0.0, 1.0])
        e1 = tmp - np.dot(tmp, n0) * n0
        e1 /= np.linalg.norm(e1)
    e2 = np.cross(n0, e1)

    dx = rng.normal(loc=0.0, scale=sigma_rad, size=n)
    dy = rng.normal(loc=0.0, scale=sigma_rad, size=n)

    r = n0 + dx[:, None] * e1[None, :] + dy[:, None] * e2[None, :]
    r /= np.linalg.norm(r, axis=1, keepdims=True)
    return r


def simulate_gw_sky(N, anisotropy_strength, cmb_axis, rng, with_anisotropy=True):
    """
    Simulate N GW merger directions.

    If with_anisotropy=True, apply dipole modulation
    p(n) ∝ 1 + A cos(gamma) along the CMB axis.
    """
    cmb_axis = np.asarray(cmb_axis, dtype=float)
    cmb_axis /= np.linalg.norm(cmb_axis)

    oversample_factor = 2
    n_try = int(N * oversample_factor)
    r = random_isotropic_directions(n_try, rng)

    if with_anisotropy:
        A = anisotropy_strength
        cos_gamma = r @ cmb_axis
        prob = 1.0 + A * cos_gamma
        prob /= prob.max()
        keep = rng.random(n_try) < prob
        r = r[keep]

    if len(r) < N:
        extra = random_isotropic_directions(N - len(r), rng)
        r = np.vstack([r, extra])
    else:
        r = r[:N]

    return r


def apply_localisation_error(r_true, sigma_loc, rng):
    """Apply Gaussian localisation error around each true direction."""
    N = r_true.shape[0]
    r_obs = np.zeros_like(r_true)
    for i in range(N):
        r_obs[i] = random_gaussian_direction_around(
            1, r_true[i], sigma_loc, rng
        )[0]
    return r_obs


# =========================
# Projection statistic
# =========================

def projection_statistic(r_obs, cmb_axis):
    """
    Improved estimator: mean projection of observed directions on the CMB axis.

       S = < n · n_cmb >

    For isotropy, S ≈ 0 (up to noise). For an aligned dipole, S shifts
    by O(ε).
    """
    cmb_axis = np.asarray(cmb_axis, dtype=float)
    cmb_axis /= np.linalg.norm(cmb_axis)
    proj = r_obs @ cmb_axis
    return proj.mean()


def simulate_catalogue_and_S(N, cmb_axis, rng, with_anisotropy, A, sigma_loc):
    """
    Simulate a single catalogue and return the projection statistic S.
    """
    r_true = simulate_gw_sky(
        N=N,
        anisotropy_strength=A,
        cmb_axis=cmb_axis,
        rng=rng,
        with_anisotropy=with_anisotropy
    )
    r_obs = apply_localisation_error(r_true, sigma_loc, rng)
    S = projection_statistic(r_obs, cmb_axis)
    return S


# =========================
# Monte Carlo forecast
# =========================

def run_for_model(N, n_real, cmb_axis, rng_base, A, sigma_loc, with_anisotropy):
    """
    Run n_real realizations for a given model and return the S distribution.

      with_anisotropy=False -> null (isotropic)
      with_anisotropy=True  -> dipole-modulated with amplitude A.
    """
    S_values = []

    local_rng = np.random.default_rng(rng_base.integers(1, 1_000_000))

    for _ in range(n_real):
        S = simulate_catalogue_and_S(
            N=N,
            cmb_axis=cmb_axis,
            rng=local_rng,
            with_anisotropy=with_anisotropy,
            A=A,
            sigma_loc=sigma_loc
        )
        S_values.append(S)

    return np.array(S_values)


def main():
    print(f"SEED = {SEED}")
    print(f"N_LIST = {N_LIST}")
    print(f"N_REALISATIONS = {N_REALISATIONS}")
    print(f"ANISO_STRENGTH = {ANISO_STRENGTH}")
    print(f"SIGMA_LOC_DEG = {SIGMA_LOC_DEG}")
    print()

    cmb_axis = np.array([0.0, 0.0, 1.0])  # placeholder CMB axis

    summary = []

    for N in N_LIST:
        print(f"=== N = {N} ===")

        # Null (isotropic) distribution of S
        S_null = run_for_model(
            N=N,
            n_real=N_REALISATIONS,
            cmb_axis=cmb_axis,
            rng_base=rng,
            A=ANISO_STRENGTH,
            sigma_loc=SIGMA_LOC,
            with_anisotropy=False
        )
        mu_null = S_null.mean()
        sigma_null = S_null.std(ddof=1)

        # Anisotropic distribution of S
        S_aniso = run_for_model(
            N=N,
            n_real=N_REALISATIONS,
            cmb_axis=cmb_axis,
            rng_base=rng,
            A=ANISO_STRENGTH,
            sigma_loc=SIGMA_LOC,
            with_anisotropy=True
        )
        mu_aniso = S_aniso.mean()
        sigma_aniso = S_aniso.std(ddof=1)

        # Detection probability: S_aniso > mu_null + k * sigma_null
        threshold = mu_null + SIGMA_THRESHOLD * sigma_null
        p_detect = np.mean(S_aniso > threshold)

        print(f"  Null:   <S> = {mu_null:.4e}, σ_S = {sigma_null:.4e}")
        print(f"  Aniso:  <S> = {mu_aniso:.4e}, σ_S = {sigma_aniso:.4e}")
        print(f"  Detection probability (> {SIGMA_THRESHOLD:.0f}σ): p ≈ {p_detect:.3f}\n")

        summary.append((N, p_detect, mu_null, sigma_null, mu_aniso, sigma_aniso))

    print("Summary (projection statistic, 3σ detection probability):")
    for (N, p_det, mu0, s0, mu1, s1) in summary:
        print(f"  N = {N:5d}:  p_detect ≈ {p_det:.3f}, "
              f"Null <S>={mu0:.4e}, Aniso <S>={mu1:.4e}")


if __name__ == "__main__":
    main()
