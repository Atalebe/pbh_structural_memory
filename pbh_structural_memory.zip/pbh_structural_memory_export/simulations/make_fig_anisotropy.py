import numpy as np
import matplotlib.pyplot as plt

# -----------------------------
# Parameters for the schematic
# -----------------------------
epsilon = 0.05  # exaggerated modulation amplitude for clarity
n_lon = 400
n_lat = 200

# Mollweide coordinates: longitude in [-pi, pi], latitude in [-pi/2, pi/2]
lon = np.linspace(-np.pi, np.pi, n_lon)
lat = np.linspace(-np.pi/2, np.pi/2, n_lat)
lon_grid, lat_grid = np.meshgrid(lon, lat)

# Choose a "CMB axis" direction (just for illustration)
# Here: lon0 = 0, lat0 = 30 degrees in equatorial-like coordinates
lon0 = 0.0
lat0 = np.deg2rad(30.0)

# Cosine of angular separation between each sky pixel and the chosen axis
cos_gamma = (
    np.sin(lat_grid) * np.sin(lat0)
    + np.cos(lat_grid) * np.cos(lat0) * np.cos(lon_grid - lon0)
)

# Dipole-like modulation: 1 + epsilon * cos(gamma)
dipole = 1.0 + epsilon * cos_gamma

# Normalize to [0, 1] for plotting
dipole_norm = (dipole - dipole.min()) / (dipole.max() - dipole.min())

# -----------------------------
# Make the Mollweide schematic
# -----------------------------
fig = plt.figure(figsize=(7, 4))
ax = fig.add_subplot(111, projection="mollweide")

# Plot the modulation
im = ax.pcolormesh(lon_grid, lat_grid, dipole_norm, shading="auto")

# Draw a marker for the axis direction
ax.plot(lon0, lat0, "o", markersize=6)

# Light grid for orientation
ax.grid(True, alpha=0.3)

# Clean up tick labels a bit
ax.set_xticklabels([])
ax.set_yticklabels([])

# Optional: a short title inside the figure (can be removed if you prefer)
ax.text(
    0.0,
    -1.3,
    "Illustrative PBH dipole-like modulation\naligned with the CMB quadrupole–octopole axis",
    ha="center",
    va="top",
    fontsize=9,
)

plt.tight_layout()

# Save as both PDF and PNG
for ext in ["pdf", "png"]:
    fname = f"fig_anisotropy.{ext}"
    fig.savefig(fname, bbox_inches="tight", dpi=300)
    print(f"Saved {fname}")

plt.close(fig)
