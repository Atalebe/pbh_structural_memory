# PBH Structural Memory – Data & Code Archive

This archive contains all simulation scripts, figures, and LaTeX source
for the paper:

**“Anisotropic Primordial Black Holes as a Fossil Record from a Pre–Big Bang Universe”**

Included:
- Monte Carlo alignment simulations (PBH–CMB projection tests)
- Dual–component PBH mass function discrimination simulations
- Gravitational–wave anisotropy projections
- All final figures (PDF + PNG)
- Complete LaTeX source + bibliography
